<?php

namespace App\Http\Livewire\Commercial\Contract;

use Livewire\Component;

class Document extends Component
{
    public function render()
    {
        return view('livewire.commercial.contract.document');
    }
}
