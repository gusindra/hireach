<?php

namespace App\Http\Livewire\Project;

use Livewire\Component;

class AddAgent extends Component
{
    public function render()
    {
        return view('livewire.project.add-agent');
    }
}
