<x-app-layout>
    <div class="">
        @livewire('chat-component')
    </div>
</x-app-layout>
