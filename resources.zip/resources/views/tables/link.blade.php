<a href="{{ $href }}" class="text-xs border-2 dark:text-slate-400 hover:border-blue-500 hover:bg-blue-100 hover:shadow-lg text-blue-600 rounded-lg px-3 py-1">{{ $slot }}</a>
