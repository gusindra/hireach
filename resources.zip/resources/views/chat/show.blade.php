<x-chat-layout>
    <div>
        @livewire('chat.chat-slug', ['team' => $team])
    </div>
</x-chat-layout>
