<div class="justify-end flex p-2">
    <!-- <div class="flex items-center justify-end px-2 text-right">
        <a href="{{ route('commercial.show', ['item']) }}" class="{{$active=='item'?'bg-gray-800':'bg-gray-400' }} inline-flex items-center px-2 py-1 bg-gray-400 border border-transparent font-normal text-xs text-white uppercase hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:shadow-outline-gray disabled:opacity-25 transition" wire:click="actionShowModal">
            {{__('Product Master Data')}}
        </a>
    </div>
    <div class="flex items-center justify-end px-2 text-right">
        <a href="{{ route('commercial.show', ['quotation']) }}" class="{{$active=='quotation'?'bg-gray-800':'bg-gray-400' }} inline-flex items-center px-2 py-1 bg-gray-400 border border-transparent font-semibold text-xs text-white uppercase hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:shadow-outline-gray disabled:opacity-25 transition" wire:click="actionShowModal">
            {{__('Quotation')}}
        </a>
    </div>
    <div class="flex items-center justify-end px-2 text-right">
        <a href="{{ route('commercial.show', ['contract']) }}" class="{{$active=='contract'?'bg-gray-800':'bg-gray-400' }} inline-flex items-center px-2 py-1  border border-transparent font-semibold text-xs text-white uppercase hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:shadow-outline-gray disabled:opacity-25 transition" wire:click="actionShowModal">
            {{__('Contract')}}
        </a>
    </div> -->
</div>
