require('./bootstrap');
require('alpinejs');
require('pikaday');
require('./livewireChart/app');

// let Pikaday = require ('pikaday/pikaday');
// window.Pikaday = Pikaday;
